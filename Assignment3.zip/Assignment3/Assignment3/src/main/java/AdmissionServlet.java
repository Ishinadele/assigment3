package Web;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Paths;
import java.util.Properties; // Add this import statement

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@WebServlet("/AdmissionServlet")
@MultipartConfig
public class ApplyServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");

        Part picturePart = request.getPart("picture");
        String pictureFileName = Paths.get(picturePart.getSubmittedFileName()).getFileName().toString();
        String pictureContentType = picturePart.getContentType();

        Part diplomaPart = request.getPart("diploma");
        String diplomaFileName = Paths.get(diplomaPart.getSubmittedFileName()).getFileName().toString();
        String diplomaContentType = diplomaPart.getContentType();

        if (!diplomaContentType.equals("application/pdf")) {
            response.getWriter().println("Diploma must be in PDF format");
            return;
        }

        sendConfirmationEmail(fullName, email);

        response.sendRedirect("confirmation.jsp");
    }

    private void sendConfirmationEmail(String fullName, String email) {
        String senderEmail = "ishinadele12@gmail.com";
        String senderPassword = "sxnh zusd zhaq imvz";

        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587"); // Port 587 for TLS

        Session session = Session.getInstance(properties, new javax.mail.Authenticator() {
            protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
                return new javax.mail.PasswordAuthentication(senderEmail, senderPassword);
            }
        });

        try {
            Message message = new MimeMessage(session);

            message.setFrom(new InternetAddress(senderEmail));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email));

            message.setSubject("Admission Submission Confirmation");
            message.setText("Dear " + fullName + ",\n\n"
                            + "Thank you for submitting your admission request. "
                            + "We have received your information and will process it shortly.\n\n"
                            + "Sincerely,"
                            + "\nYour University Admission Team");

            Transport.send(message);

            System.out.println("Confirmation email sent successfully to " + email);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}
