import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebFilter("/admissionForm.jsp")
public class AuthenticationFilter implements Filter {




        public void init(FilterConfig filterConfig) throws ServletException {
        }

        public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
                throws IOException, ServletException {
            HttpServletRequest httpRequest = (HttpServletRequest) request;
            HttpServletResponse httpResponse = (HttpServletResponse) response;

            HttpSession session = httpRequest.getSession(false);

            // Check if the user is logged in
            if (session == null || session.getAttribute("signup") == null) {
                httpResponse.sendRedirect(httpRequest.getContextPath() + "/login.jsp");
            } else {
                // User is authenticated, continue with the request
                chain.doFilter(request, response);
            }
        }

        public void destroy() {
        }
    }



