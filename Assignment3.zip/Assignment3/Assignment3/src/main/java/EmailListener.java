import jakarta.jms.Message;
import jakarta.mail.Session;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;

import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.util.Properties;

@WebListener
public class EmailListener implements ServletContextListener {
        @Override
        public void contextInitialized(ServletContextEvent servletContextEvent) {
            // Initialization code, if needed
        }

        @Override
        public void contextDestroyed(ServletContextEvent servletContextEvent) {
            // Cleanup code, if needed
        }

        public static void sendConfirmationEmail(String recipientEmail, String firstName, String lastName) {
            // Sender's email and password (replace with your own)
            String senderEmail = "your.email@example.com";
            String senderPassword = "your_email_password";

            // Setup mail server properties
            Properties properties = new Properties();
            properties.put("mail.smtp.auth", "true");
            properties.put("mail.smtp.starttls.enable", "true");
            properties.put("mail.smtp.host", "smtp.example.com"); // Replace with your SMTP server
            properties.put("mail.smtp.port", "587"); // Replace with your SMTP server port

            // Create a session with the specified properties
            Session session = Session.getInstance(properties, new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(senderEmail, senderPassword);
                }
            });

            try {
                // Create a default MimeMessage object
                Message message = new MimeMessage(session);

                // Set the sender and recipient addresses
                ((MimeMessage) message).setFrom(new InternetAddress(senderEmail));
                message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));

                // Set the email subject and content
                message.setSubject("Admission Submission Confirmation");
                message.setText("Dear " + firstName + " " + lastName + ",\n\n"
                        + "Thank you for submitting your admission request. "
                        + "We have received your information and will process it shortly.\n\n"
                        + "Sincerely,\nYour University Admission Team");

                // Send the email
                Transport.send(message);

                System.out.println("Confirmation email sent to: " + recipientEmail);
            } catch (MessagingException e) {
                e.printStackTrace();
            }
        }
    }


