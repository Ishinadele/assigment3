import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String validEmail = "ishinadele@gmail.com";
        String validPassword = "auca@2024";


        String enteredEmail = request.getParameter("email");
        String enteredPassword = request.getParameter("password");


        if (validEmail.equals(enteredEmail) && validPassword.equals(enteredPassword)) {
            // Authentication successful

            // Create a new session or retrieve the existing session
            HttpSession session = request.getSession(true);

            // Set user attribute in the session
            session.setAttribute("signup", enteredEmail);

            // Set session timeout (in seconds) - adjust as needed
            session.setMaxInactiveInterval(60 * 30); // 30 minutes

            response.sendRedirect("admissionForm.jsp");
        } else {
            // Authentication failed, redirect back to the login page with an error message
            response.sendRedirect("login.jsp?error=1");
        }
    }
}
